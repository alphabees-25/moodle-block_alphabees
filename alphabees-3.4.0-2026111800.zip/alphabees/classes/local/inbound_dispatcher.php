<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Verifies and dispatches inbound signed requests from the Alphabees backend.
 *
 * Pure-functions style: no direct echo / header() calls — those happen in
 * api.php which calls into here. This makes the dispatcher unit-testable.
 *
 * @package   block_alphabees
 * @copyright 2026 Alphabees
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_alphabees\local;

/**
 * Inbound dispatcher.
 */
class inbound_dispatcher {
    /**
     * Verify and dispatch an inbound signed request.
     *
     * Result envelope shape: { httpStatus: int, body: array }.
     *
     * @param string $method HTTP method.
     * @param string $path Request path.
     * @param array $headers Request headers (case-insensitive lookup).
     * @param string $rawbody Raw request body.
     * @return array
     */
    public static function handle(string $method, string $path, array $headers, string $rawbody): array {
        // Method/path basic checks. Wrong method → 405 with no diagnostic info.
        if (strtoupper($method) !== 'POST') {
            return self::deny(405);
        }

        $verification = self::verify_signature($method, $path, $headers, $rawbody);
        if (!$verification['ok']) {
            // Log internally, return uniform 401 so timing/error doesn't leak which step failed.
            debugging('[block_alphabees] inbound verify failed: ' . $verification['reason'], DEBUG_DEVELOPER);
            return self::deny(401);
        }

        $body = json_decode($rawbody, true);
        if (!is_array($body)) {
            return self::deny(400);
        }

        $action = self::normalise_action($body);
        if ($action === '') {
            return self::deny(400);
        }
        $params = isset($body['params']) && is_array($body['params']) ? $body['params'] : [];

        return self::execute(caller::site(), $action, $params);
    }

    /**
     * Run one action on behalf of an already-authenticated caller.
     *
     * Shared by both entrances into the registry: api.php reaches this with a
     * site caller once the Ed25519 signature holds, and the console gateway
     * reaches it with a user caller once Moodle has established the session.
     * Whether that caller may run this action at all is decided in one place,
     * {@see action_policy::require_permitted()}, before the switch.
     *
     * @param caller $caller Who is asking.
     * @param string $action Registry action name.
     * @param array $params Action parameters.
     * @return array Envelope { httpStatus: int, body: array }.
     */
    public static function execute(caller $caller, string $action, array $params): array {
        if (!action_policy::known($action)) {
            return self::deny(404);
        }

        try {
            action_policy::require_permitted($caller, $action, $params);
        } catch (\required_capability_exception $e) {
            return self::deny(403, ['code' => 'capability_required']);
        } catch (\moodle_exception $e) {
            // Unknown to this caller, or the parameters did not name a course
            // we could check against. Both are refusals, not server errors.
            return self::deny(403, ['code' => 'action_not_permitted']);
        }

        switch ($action) {
            case 'ping':
                return self::ok(self::action_ping());
            case 'describe_actions':
                return self::ok(self::action_describe_actions());
            case 'disconnect_site':
            case 'revoke_registration':
                return self::action_disconnect_site($params);
            case 'pause_site':
                return self::ok(self::action_pause_site($params));
            case 'resume_site':
                return self::action_resume_site($params);
            case 'list_placements':
                return self::ok(self::action_list_placements());
            case 'update_placement':
                return self::action_update_placement($params);
            case 'delete_placement':
                return self::action_delete_placement($params);
            case 'create_placement':
                return self::action_create_placement($params);
            case 'bulk_create_placements':
                return self::action_bulk_create_placements($params);
            case 'list_courses':
                return self::ok(self::action_list_courses($params));
            case 'list_courses_categorized':
                return self::ok(self::action_list_courses_categorized($params));
            case 'upsert_course':
                return self::action_upsert_course($params);
            case 'upsert_section':
                return self::action_upsert_section($params);
            case 'upsert_modules':
                return self::action_upsert_modules($params);
            case 'delete_course_modules':
                return self::action_delete_course_modules($params);
            case 'set_activity_completion':
                return self::action_set_activity_completion($params);
            case 'set_grades':
                return self::action_set_grades($params);
            case 'list_grade_items':
                return self::action_list_grade_items($params);
            case 'delete_grade_item':
                return self::action_delete_grade_item($params);
            case 'upload_file':
                return self::action_upload_file($params);
            case 'list_h5p_libraries':
                return self::action_list_h5p_libraries($params);
            case 'list_generico_templates':
                return self::action_list_generico_templates($params);
            case 'get_user_access':
                return self::action_get_user_access($params);
            case 'get_activity_text':
                return self::action_get_activity_text($params);
            case 'notify':
                return self::action_notify($params);
            case 'console_context':
            case 'get_learner_overview':
            case 'send_user_message':
                return self::run_console_action($caller, $action, $params);
            default:
                return self::deny(404);
        }
    }

    /**
     * Verify the request signature, timestamp, nonce, key id, site identifier.
     *
     * Returns { ok: bool, reason?: string }.
     */
    private static function verify_signature(string $method, string $path, array $headers, string $body): array {
        $algo = self::header($headers, 'X-Alphabees-Algo');
        $site = self::header($headers, 'X-Alphabees-Site');
        $keyid = self::header($headers, 'X-Alphabees-KeyId');
        $ts = self::header($headers, 'X-Alphabees-Timestamp');
        $nonce = self::header($headers, 'X-Alphabees-Nonce');
        $sig = self::header($headers, 'X-Alphabees-Signature');

        if ($algo !== 'ed25519') {
            return ['ok' => false, 'reason' => 'algo'];
        }
        if ($site !== site_registry::site_identifier()) {
            return ['ok' => false, 'reason' => 'site'];
        }
        if ((int)$keyid !== site_registry::backend_key_id()) {
            return ['ok' => false, 'reason' => 'keyid'];
        }
        if (!ctype_digit((string)$ts) || !crypto::timestamp_within_window((int)$ts)) {
            return ['ok' => false, 'reason' => 'timestamp'];
        }
        if (!preg_match('/^[A-Za-z0-9_-]{16,}$/', (string)$nonce)) {
            return ['ok' => false, 'reason' => 'nonce_format'];
        }

        if (self::nonce_seen($nonce)) {
            return ['ok' => false, 'reason' => 'nonce_replay'];
        }

        $backendpub = site_registry::backend_public_key();
        if ($backendpub === null) {
            return ['ok' => false, 'reason' => 'no_backend_key'];
        }

        $canonical = crypto::canonical_string($method, $path, (int)$ts, $nonce, $body, $site);
        if (!crypto::verify($canonical, $sig, $backendpub)) {
            return ['ok' => false, 'reason' => 'signature'];
        }

        // Mark nonce as used (TTL: timestamp window + slack).
        self::record_nonce($nonce, (int)$ts);
        return ['ok' => true];
    }

    /**
     * Case-insensitive header lookup.
     *
     * @param array $headers
     * @param string $name
     * @return string
     */
    private static function header(array $headers, string $name): string {
        $needle = strtolower($name);
        foreach ($headers as $k => $v) {
            if (strtolower($k) === $needle) {
                return is_array($v) ? (string)reset($v) : (string)$v;
            }
        }
        return '';
    }

    /**
     * Check whether a nonce has already been recorded for this site.
     *
     * @param string $nonce
     * @return bool
     */
    private static function nonce_seen(string $nonce): bool {
        global $DB;
        return $DB->record_exists('block_alphabees_nonces', ['nonce' => $nonce]);
    }

    /**
     * Record a nonce as used so subsequent requests with the same nonce are rejected.
     *
     * @param string $nonce
     * @param int $requestts Request timestamp (drives the TTL).
     * @return void
     */
    private static function record_nonce(string $nonce, int $requestts): void {
        global $DB;
        $expiry = $requestts + (crypto::TIMESTAMP_WINDOW_SECONDS * 2);
        try {
            $DB->insert_record('block_alphabees_nonces', (object)[
                'nonce' => $nonce,
                'expiresat' => $expiry,
            ]);
        } catch (\dml_write_exception $e) {
            // Race condition: another request inserted the same nonce concurrently.
            // Caller already passed the nonce_seen check, but this defensive catch
            // keeps the request from 500'ing on duplicate-key.
            unset($e);
        }
    }

    // Actions.

    /**
     * Health check action — returns plugin version, placement count, current key id.
     *
     * @return array
     */
    private static function action_ping(): array {
        $plugin = new \stdClass();
        require(__DIR__ . '/../../version.php');
        return [
            'plugin_version' => $plugin->release ?? null,
            'plugin_version_code' => $plugin->version ?? null,
            'capabilities' => plugin_features::list(),
            'placement_count' => count(placement_repository::all_instances()),
            'key_id' => site_registry::key_id(),
            'backend_key_id' => site_registry::backend_key_id(),
            'registration_id' => site_registry::registration_id(),
            'api_key_present' => site_registry::api_key_present(),
            'api_key_status' => site_registry::api_key_status(),
            'last_sync_at' => site_registry::last_sync_at(),
            'sync_paused' => site_registry::is_sync_paused(),
            'sync_paused_at' => site_registry::sync_paused_at(),
        ];
    }

    /**
     * Fully disconnect this Moodle site from the portal.
     *
     * This is intentionally a local teardown only: it revokes active web-service
     * tokens/assignments and clears registration state, but leaves the dedicated
     * Moodle user and role definitions in place for a future reconnect.
     *
     * @return array
     */
    private static function action_disconnect_site(array $params): array {
        global $DB;

        try {
            ws_setup::disable();
        } catch (\Throwable $e) {
            return self::deny(500, [
                'success' => false,
                'action' => 'disconnect_site',
                'status' => 'failed',
                'error' => 'ws_disable_failed',
                'detail' => $e->getMessage(),
            ]);
        }

        $DB->delete_records('block_alphabees_retryqueue');
        site_registry::reset_registration();
        $reason = self::param($params, 'reason', 'reason');
        site_registry::mark_portal_disconnected($reason !== null ? (string)$reason : null);
        ws_setup::record_token_post_status('revoked_ok');

        return self::ok([
            'success' => true,
            'action' => 'disconnect_site',
            'status' => 'disconnected',
            'disconnected' => true,
            'registered' => site_registry::is_registered(),
            'portal_disconnected' => site_registry::is_portal_disconnected(),
            'ws_enabled' => (bool)get_config('block_alphabees', 'ws_enabled'),
            'allow_remote_placement' => (bool)get_config('block_alphabees', 'allow_remote_placement'),
            'retry_queue_cleared' => true,
        ]);
    }

    /**
     * Pause outbound placement syncs/events while keeping registration intact.
     *
     * @param array $params
     * @return array
     */
    private static function action_pause_site(array $params): array {
        $reason = self::param($params, 'reason', 'reason');
        site_registry::pause_syncs($reason !== null ? (string)$reason : null);

        return [
            'success' => true,
            'action' => 'pause_site',
            'status' => 'paused',
            'api_key_present' => site_registry::api_key_present(),
            'api_key_status' => site_registry::api_key_status(),
            'sync_paused' => site_registry::is_sync_paused(),
            'sync_paused_at' => site_registry::sync_paused_at(),
            'sync_pause_reason' => site_registry::sync_pause_reason(),
        ];
    }

    /**
     * Resume outbound placement syncs/events after a portal pause.
     *
     * @param array $params
     * @return array
     */
    private static function action_resume_site(array $params): array {
        $requireapi = self::truthy(self::param($params, 'require_api_key', 'requireApiKey'));
        $pausedbefore = site_registry::is_sync_paused();

        if (!site_registry::api_key_present()) {
            return self::deny(409, [
                'success' => false,
                'action' => 'resume_site',
                'status' => 'blocked',
                'error' => 'api_key_missing',
                'require_api_key' => $requireapi,
                'api_key_present' => false,
                'api_key_status' => 'missing',
            ]);
        }
        if (site_registry::is_registration_blocked()) {
            return self::deny(409, [
                'success' => false,
                'action' => 'resume_site',
                'status' => 'blocked',
                'error' => 'api_key_rejected',
                'require_api_key' => $requireapi,
                'api_key_present' => true,
                'api_key_status' => site_registry::api_key_status(),
                'detail' => site_registry::registration_block_reason(),
            ]);
        }

        self::drop_queued_lifecycle_event('site.paused');
        self::drop_queued_lifecycle_event('site.resumed');
        site_registry::resume_syncs();

        return self::ok([
            'success' => true,
            'action' => 'resume_site',
            'status' => 'resumed',
            'require_api_key' => $requireapi,
            'api_key_present' => site_registry::api_key_present(),
            'api_key_status' => site_registry::api_key_status(),
            'sync_paused_before' => $pausedbefore,
            'sync_paused' => site_registry::is_sync_paused(),
            'sync_paused_at' => site_registry::sync_paused_at(),
            'sync_pause_reason' => site_registry::sync_pause_reason(),
        ]);
    }

    /**
     * Return the full snapshot of placements known to this site.
     *
     * @return array
     */
    private static function action_list_placements(): array {
        $instances = placement_repository::all_instances();
        $payloads = [];
        foreach ($instances as $instance) {
            $payloads[] = placement_repository::build_payload($instance);
        }
        return ['placements' => $payloads];
    }

    /**
     * Apply a remote update to an existing placement (bot, visibility, primary color).
     *
     * @param array $params
     * @return array
     */
    private static function action_update_placement(array $params): array {
        global $DB;
        $uuid = self::param($params, 'placement_uuid', 'placementUuid');
        if ($uuid === null || $uuid === '') {
            return self::deny(400, ['error' => 'missing_placement_uuid']);
        }
        $instance = placement_repository::find_by_uuid($uuid);
        if ($instance === null) {
            return self::deny(404, ['error' => 'placement_not_found']);
        }

        $config = placement_repository::decode_config($instance->configdata ?? '');
        $changed = false;

        // Bot/tutor change.
        $newbot = self::param($params, 'bot_id', 'botId');
        if ($newbot !== null) {
            $oldbot = isset($config->botid) ? (string)$config->botid : '';
            if ((string)$newbot !== $oldbot) {
                $config->botid = (string)$newbot;
                unset($config->bot_label);
                $changed = true;
            }
            if (
                $oldbot === ''
                && (string)$newbot !== ''
                && self::param($params, 'visible', 'visible') === null
                && isset($config->placement_visible)
                && !$config->placement_visible
            ) {
                $config->placement_visible = 1;
                $changed = true;
            }
        }
        $newbotlabel = self::bot_label_from_params($params);
        if ($newbotlabel !== '') {
            $oldbotlabel = isset($config->bot_label) ? (string)$config->bot_label : '';
            if ($newbotlabel !== $oldbotlabel) {
                $config->bot_label = $newbotlabel;
                $changed = true;
            }
        }

        // Visibility toggle. Stored as `placement_visible` in configdata so it
        // doesn't collide with Moodle's own block_instances.visible. Empty
        // content is returned by get_content() when this is false; the block
        // remains in block_instances so re-enabling is a single param flip.
        $newvisible = self::param($params, 'visible', 'visible');
        if ($newvisible !== null) {
            $newvisbool = self::to_bool($newvisible);
            $oldvisbool = !isset($config->placement_visible) ? true : (bool)$config->placement_visible;
            if ($newvisbool !== $oldvisbool) {
                $config->placement_visible = $newvisbool ? 1 : 0;
                $changed = true;
            }
        }

        // Primary color override. When set (hex string like #abcdef), this
        // overrides the auto-fetched-from-bot color in get_content(). When
        // explicitly null, override is cleared.
        if (array_key_exists('primary_color', $params) || array_key_exists('primaryColor', $params)) {
            $newcolor = self::param($params, 'primary_color', 'primaryColor');
            if ($newcolor === null || $newcolor === '') {
                if (isset($config->primary_color_override)) {
                    unset($config->primary_color_override);
                    $changed = true;
                }
            } else {
                $hex = self::sanitize_hex_color((string)$newcolor);
                $oldcolor = isset($config->primary_color_override) ? (string)$config->primary_color_override : '';
                if ($hex !== null && $hex !== $oldcolor) {
                    $config->primary_color_override = $hex;
                    $changed = true;
                }
            }
        }

        if (empty($config->remote_managed)) {
            $config->remote_managed = true;
            $changed = true;
        }

        if ($changed) {
            $DB->update_record('block_instances', (object)[
                'id' => $instance->id,
                'configdata' => placement_repository::encode_config($config),
                'timemodified' => time(),
            ]);
        }

        return self::ok(['placement' => placement_repository::build_payload(
            (object)array_merge((array)$instance, [
                'configdata' => placement_repository::encode_config($config),
                'timemodified' => time(),
            ])
        )]);
    }

    /**
     * Coerce a JSON-decoded value to bool, accepting common truthy/falsy strings.
     *
     * @param mixed $v
     * @return bool
     */
    private static function to_bool($v): bool {
        if (is_bool($v)) {
            return $v;
        }
        if (is_int($v)) {
            return $v !== 0;
        }
        if (is_string($v)) {
            $low = strtolower(trim($v));
            return in_array($low, ['1', 'true', 'yes', 'on'], true);
        }
        return (bool)$v;
    }

    /**
     * Validate + normalize a hex color string. Returns "#aabbcc" or null
     * if input doesn't look like a hex color. Accepts forms with or
     * without a leading `#`, 3-digit shorthand, and uppercase letters.
     */
    private static function sanitize_hex_color(string $value): ?string {
        $v = ltrim(trim($value), '#');
        if (preg_match('/^[0-9a-fA-F]{6}$/', $v)) {
            return '#' . strtolower($v);
        }
        if (preg_match('/^[0-9a-fA-F]{3}$/', $v)) {
            // Expand short form: abc → aabbcc.
            return '#' . strtolower($v[0] . $v[0] . $v[1] . $v[1] . $v[2] . $v[2]);
        }
        return null;
    }

    /**
     * Build a readable tutor label from optional backend action params.
     *
     * The canonical source for dropdown names remains the live tutor list, but
     * storing this label avoids showing a raw UUID if that list is temporarily
     * unavailable or filtered before the next form render.
     *
     * @param array $params
     * @return string
     */
    private static function bot_label_from_params(array $params): string {
        $visualname = self::string_param_any($params, [
            'bot_visual_name', 'botVisualName', 'visual_name', 'visualName', 'display_name', 'displayName',
        ]);
        $internalname = self::string_param_any($params, [
            'bot_name', 'botName', 'name', 'internal_name', 'internalName',
        ]);
        $type = self::string_param_any($params, [
            'bot_type', 'botType', 'type', 'agent_type', 'agentType',
        ]);

        $parts = [];
        if ($visualname !== '') {
            $parts[] = $visualname;
        }
        if ($internalname !== '' && $internalname !== $visualname) {
            $parts[] = $internalname;
        }
        if ($type !== '') {
            $parts[] = ucwords(str_replace(['_', '-'], ' ', $type));
        }
        return clean_param(implode(' · ', $parts), PARAM_TEXT);
    }

    /**
     * Delete a placement by its UUID.
     *
     * @param array $params
     * @return array
     */
    private static function action_delete_placement(array $params): array {
        global $CFG;
        require_once($CFG->dirroot . '/lib/blocklib.php');

        $uuid = self::param($params, 'placement_uuid', 'placementUuid');
        if ($uuid === null || $uuid === '') {
            return self::deny(400, ['error' => 'missing_placement_uuid']);
        }
        $instance = placement_repository::find_by_uuid($uuid);
        if ($instance === null) {
            return self::deny(404, ['error' => 'placement_not_found']);
        }

        blocks_delete_instance($instance);
        return self::ok(['deleted' => true]);
    }

    /**
     * Create a new alphabees block instance on a target course or module page.
     *
     * Gated by the `allow_remote_placement` admin setting (off by default) —
     * giving the portal write access to add blocks anywhere is powerful and
     * the site admin must consciously opt in.
     *
     * Required params: course_id or target_type=module + cmid.
     * Optional params: target_type (default `course`),
     *                  bot_id,
     *                  visible,
     *                  page_pattern (default `course-view-*` or `mod-{modtype}-*`),
     *                  block_region (default `side-pre`),
     *                  block_weight (default 0).
     *
     * Returns the full placement payload (same shape as list_placements rows).
     */
    private static function action_create_placement(array $params): array {
        if (empty(get_config('block_alphabees', 'allow_remote_placement'))) {
            return self::deny(403, ['error' => 'remote_placement_disabled']);
        }

        try {
            $result = self::create_placement_for_target($params);
        } catch (\Throwable $e) {
            debugging('[block_alphabees] create_placement failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return self::deny(500, ['error' => 'internal', 'detail' => $e->getMessage()]);
        }
        if (empty($result['ok'])) {
            return self::deny((int)($result['status'] ?? 400), $result);
        }

        return self::ok(['placement' => $result['placement']]);
    }

    /**
     * Create multiple placements while reporting each target independently.
     *
     * @param array $params
     * @return array
     */
    private static function action_bulk_create_placements(array $params): array {
        if (empty(get_config('block_alphabees', 'allow_remote_placement'))) {
            return self::deny(403, ['error' => 'remote_placement_disabled']);
        }

        $targets = self::param($params, 'targets', 'targets');
        if (!is_array($targets) || empty($targets)) {
            return self::deny(400, ['error' => 'missing_targets']);
        }

        $results = [];
        foreach ($targets as $index => $target) {
            if (!is_array($target)) {
                $results[] = [
                    'ok' => false,
                    'index' => $index,
                    'error' => 'invalid_target',
                ];
                continue;
            }

            try {
                $result = self::create_placement_for_target($target);
            } catch (\Throwable $e) {
                debugging('[block_alphabees] bulk_create_placements target failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
                $result = [
                    'ok' => false,
                    'status' => 500,
                    'error' => 'internal',
                    'detail' => $e->getMessage(),
                ];
            }
            $result['index'] = $index;
            $results[] = $result;
        }

        $created = 0;
        foreach ($results as $result) {
            if (!empty($result['ok'])) {
                $created++;
            }
        }

        return self::ok([
            'results' => $results,
            'created_count' => $created,
            'error_count' => count($results) - $created,
        ]);
    }

    /**
     * Create one block_instances row for either a course or module target.
     *
     * @param array $params
     * @return array
     */
    private static function create_placement_for_target(array $params): array {
        global $DB;

        $targettype = strtolower((string)(self::param($params, 'target_type', 'targetType') ?? 'course'));
        if ($targettype === 'activity') {
            $targettype = 'module';
        }
        if (!in_array($targettype, ['course', 'module'], true)) {
            return [
                'ok' => false,
                'status' => 400,
                'target_type' => $targettype,
                'error' => 'invalid_target_type',
            ];
        }

        $botid = clean_param((string)(self::param($params, 'bot_id', 'botId') ?? ''), PARAM_TEXT);

        $courseid = (int)(self::param($params, 'course_id', 'courseId') ?? 0);
        $cmid = null;
        $modtype = null;
        $activityname = null;
        if ($targettype === 'module') {
            $cmid = (int)(self::param($params, 'cmid', 'cmid')
                ?? self::param($params, 'course_module_id', 'courseModuleId') ?? 0);
            if ($cmid <= 0) {
                return [
                    'ok' => false,
                    'status' => 400,
                    'target_type' => 'module',
                    'course_id' => $courseid > 0 ? $courseid : null,
                    'error' => 'missing_cmid',
                ];
            }

            $sql = "SELECT cm.id, cm.course, cm.instance, m.name AS modtype
                      FROM {course_modules} cm
                      JOIN {modules} m ON m.id = cm.module
                     WHERE cm.id = ?";
            $cm = $DB->get_record_sql($sql, [$cmid], IGNORE_MISSING);
            if (!$cm) {
                return [
                    'ok' => false,
                    'status' => 404,
                    'target_type' => 'module',
                    'cmid' => $cmid,
                    'error' => 'module_not_found',
                ];
            }

            if ($courseid > 0 && $courseid !== (int)$cm->course) {
                return [
                    'ok' => false,
                    'status' => 400,
                    'target_type' => 'module',
                    'course_id' => $courseid,
                    'cmid' => $cmid,
                    'error' => 'module_course_mismatch',
                ];
            }

            $courseid = (int)$cm->course;
            $modtype = (string)$cm->modtype;
            $expectedmodtype = (string)(self::param($params, 'modtype', 'modType') ?? '');
            if ($expectedmodtype !== '' && $expectedmodtype !== $modtype) {
                return [
                    'ok' => false,
                    'status' => 400,
                    'target_type' => 'module',
                    'course_id' => $courseid,
                    'cmid' => $cmid,
                    'modtype' => $modtype,
                    'error' => 'modtype_mismatch',
                ];
            }

            try {
                $activityname = $DB->get_field($modtype, 'name', ['id' => $cm->instance], IGNORE_MISSING);
                $activityname = $activityname !== false ? (string)$activityname : null;
            } catch (\Throwable $e) {
                unset($e);
                $activityname = null;
            }
            $parentcontext = \context_module::instance($cmid);
        } else {
            if ($courseid <= 0) {
                return [
                    'ok' => false,
                    'status' => 400,
                    'target_type' => 'course',
                    'error' => 'missing_course_id',
                ];
            }
            $course = $DB->get_record('course', ['id' => $courseid], 'id', IGNORE_MISSING);
            if (!$course) {
                return [
                    'ok' => false,
                    'status' => 404,
                    'target_type' => 'course',
                    'course_id' => $courseid,
                    'error' => 'course_not_found',
                ];
            }
            $parentcontext = \context_course::instance($courseid);
        }

        $region = clean_param((string)(self::param($params, 'block_region', 'blockRegion') ?? 'side-pre'), PARAM_TEXT);
        $weight = (int)(self::param($params, 'block_weight', 'blockWeight') ?? 0);
        $defaultpattern = $targettype === 'module' ? 'mod-' . $modtype . '-*' : 'course-view-*';
        $pagepattern = clean_param(
            (string)(self::param($params, 'page_pattern', 'pagePattern') ?? $defaultpattern),
            PARAM_TEXT
        );

        $configdata = new \stdClass();
        if ($botid !== '') {
            $configdata->botid = $botid;
        }
        $botlabel = self::bot_label_from_params($params);
        if ($botid !== '' && $botlabel !== '') {
            $configdata->bot_label = $botlabel;
        }
        $configdata->placement_uuid = crypto::uuid_v4();
        $configdata->remote_managed = 1;
        $visible = self::param($params, 'visible', 'visible');
        if ($visible !== null) {
            $configdata->placement_visible = self::to_bool($visible) ? 1 : 0;
        } else if ($botid === '') {
            $configdata->placement_visible = 0;
        }

        $record = new \stdClass();
        $record->blockname = 'alphabees';
        $record->parentcontextid = $parentcontext->id;
        $record->showinsubcontexts = 0;
        $record->requiredbytheme = 0;
        $record->pagetypepattern = $pagepattern;
        $record->subpagepattern = null;
        $record->defaultregion = $region;
        $record->defaultweight = $weight;
        $record->configdata = placement_repository::encode_config($configdata);
        $record->timecreated = time();
        $record->timemodified = time();
        $instanceid = $DB->insert_record('block_instances', $record);

        $instance = $DB->get_record('block_instances', ['id' => $instanceid]);
        if ($instance) {
            placement_repository::claim_uuid($instance, $configdata);
            $instance->configdata = placement_repository::encode_config($configdata);
        }
        if (!$instance) {
            return [
                'ok' => false,
                'status' => 500,
                'target_type' => $targettype,
                'course_id' => $courseid,
                'cmid' => $cmid,
                'modtype' => $modtype,
                'activity_name' => $activityname,
                'error' => 'create_failed',
            ];
        }

        $placement = placement_repository::build_payload($instance);
        return [
            'ok' => true,
            'target_type' => $targettype,
            'course_id' => $courseid,
            'cmid' => $cmid,
            'modtype' => $modtype,
            'activity_name' => $activityname,
            'placement_uuid' => $placement['placement_uuid'] ?? null,
            'placement' => $placement,
        ];
    }

    /**
     * Return the list of courses on this Moodle, so the portal can offer
     * a course picker when an admin wants to autonomously place an
     * Alphabees block somewhere new.
     *
     * Pagination via `limit` / `offset` params (defaults 500 / 0) so we
     * stay safe on large Moodle installs without a single huge response.
     * Site course (id=1) is excluded — it's not a real course context.
     */
    private static function action_list_courses(array $params): array {
        global $DB;

        $limit = (int)(self::param($params, 'limit', 'limit') ?? 500);
        if ($limit <= 0 || $limit > 2000) {
            $limit = 500;
        }
        $offset = (int)(self::param($params, 'offset', 'offset') ?? 0);
        if ($offset < 0) {
            $offset = 0;
        }

        $sql = "SELECT c.id, c.shortname, c.fullname, c.category, c.format,
                       c.visible, c.startdate, c.enddate,
                       cc.name AS category_name
                  FROM {course} c
                  LEFT JOIN {course_categories} cc ON cc.id = c.category
                 WHERE c.id > 1
              ORDER BY c.id ASC";
        $rows = $DB->get_records_sql($sql, [], $offset, $limit);

        $total = (int)$DB->count_records_select('course', 'id > 1');

        $courses = [];
        foreach ($rows as $r) {
            $courses[] = [
                'id' => (int)$r->id,
                'shortname' => (string)$r->shortname,
                'fullname' => (string)$r->fullname,
                'category_id' => (int)$r->category,
                'category_name' => $r->category_name !== null ? (string)$r->category_name : null,
                'visible' => (bool)$r->visible,
                'format' => (string)$r->format,
                'startdate' => isset($r->startdate) && $r->startdate ? (int)$r->startdate : null,
                'enddate' => isset($r->enddate) && $r->enddate ? (int)$r->enddate : null,
            ];
        }

        return [
            'courses' => $courses,
            'count' => count($courses),
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => ($offset + count($courses)) < $total,
        ];
    }

    /**
     * Course-categorised listing for the portal's course picker.
     *
     * Same shape as list_courses but joins category metadata so the portal
     * can render a category tree without a second round-trip.
     *
     * @param array $params
     * @return array
     */
    private static function action_list_courses_categorized(array $params): array {
        $limit = (int)(self::param($params, 'limit', 'limit') ?? 500);
        if ($limit <= 0 || $limit > 2000) {
            $limit = 500;
        }
        $offset = (int)(self::param($params, 'offset', 'offset') ?? 0);
        if ($offset < 0) {
            $offset = 0;
        }
        return course_writer::list_courses_categorized($limit, $offset);
    }

    /**
     * Atomically create or update a course (matched by id or shortname).
     *
     * @param array $params
     * @return array
     */
    private static function action_upsert_course(array $params): array {
        $courseparams = self::map_course_params($params);
        try {
            $course = course_writer::upsert_course($courseparams);
        } catch (\moodle_exception $e) {
            return self::deny(400, ['error' => 'invalid_params', 'detail' => $e->getMessage()]);
        } catch (\Throwable $e) {
            debugging('[block_alphabees] upsert_course failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return self::deny(500, ['error' => 'internal', 'detail' => $e->getMessage()]);
        }
        return self::ok(['course' => self::shape_course($course)]);
    }

    /**
     * Update one section of a course (name, summary HTML, visibility).
     *
     * Replaces the function previously provided by local_wsmanagesections —
     * the third-party plugin is no longer required for HTML summaries.
     *
     * @param array $params
     * @return array
     */
    private static function action_upsert_section(array $params): array {
        $courseid = (int)(self::param_any($params, ['course_id', 'courseId', 'courseid', 'course']) ?? 0);
        $sectionnum = (int)(self::param_any($params, ['section', 'sectionnum', 'section_num', 'sectionNum']) ?? -1);
        if ($courseid <= 0) {
            return self::deny(400, ['error' => 'missing_course', 'detail' => 'Pass course_id (or courseid).']);
        }
        if ($sectionnum < 0) {
            return self::deny(400, ['error' => 'missing_section', 'detail' => 'Pass section (or sectionnum), 0-based.']);
        }
        $fields = [];
        $coursefields = [
            'name' => 'name',
            'summary' => 'summary',
            'summary_format' => 'summaryFormat',
            'visible' => 'visible',
        ];
        foreach ($coursefields as $snake => $camel) {
            $value = self::param($params, $snake, $camel);
            if ($value !== null) {
                $key = $snake === 'summary_format' ? 'summaryformat' : $snake;
                $fields[$key] = $value;
            }
        }
        try {
            $section = course_writer::upsert_section($courseid, $sectionnum, $fields);
        } catch (\Throwable $e) {
            debugging('[block_alphabees] upsert_section failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return self::deny(500, ['error' => 'internal', 'detail' => $e->getMessage()]);
        }
        return self::ok(['section' => [
            'id' => (int)$section->id,
            'course_id' => (int)$section->course,
            'section' => (int)$section->section,
            'name' => $section->name !== null ? (string)$section->name : null,
            'summary' => (string)$section->summary,
            'summary_format' => (int)$section->summaryformat,
            'visible' => (bool)$section->visible,
        ]]);
    }

    /**
     * Publish the parameters this site's write actions accept.
     *
     * The equivalent of a web service's published signature, which a signed
     * channel does not get for free. A caller can read this instead of
     * guessing a spelling or matching against documentation written for a
     * different plugin version — the answer comes from the same declaration
     * the mapper uses, so it cannot drift from the behaviour.
     *
     * @return array
     */
    private static function action_describe_actions(): array {
        $version = plugin_features::version();
        return [
            // Historically the installed version code, under this name.
            'plugin_version' => get_config('block_alphabees', 'version'),
            'plugin_version_code' => $version['version'],
            'plugin_release' => $version['release'],
            'capabilities' => plugin_features::list(),
            'actions' => param_schema::describe(),
        ];
    }

    /**
     * Bulk add or update course modules.
     *
     * Accepts a `modules` array; each entry is either { cmid, ... } for an
     * update or { section, modname, ... } for a create.
     *
     * The course id may be given **once at the top level** next to `modules`,
     * the way upsert_course and upsert_section take it, and then applies to
     * every entry that does not name its own. Until 3.1.1 it was read per
     * entry only, so a batch addressed the way the sibling course actions are
     * addressed was refused with a bare "invalidparameter" on every module —
     * the writer's own explanation never left the server.
     *
     * @param array $params
     * @return array
     */
    private static function action_upsert_modules(array $params): array {
        $modules = self::param($params, 'modules', 'modules');
        if (!is_array($modules) || empty($modules)) {
            return self::deny(400, ['error' => 'missing_modules']);
        }
        $actor = self::actor_user();
        if (!$actor) {
            return self::deny(403, ['error' => 'no_actor_user']);
        }
        $defaultcourse = self::param_any($params, ['course_id', 'courseId', 'courseid', 'course']);

        $results = [];
        foreach ($modules as $idx => $entry) {
            if (!is_array($entry)) {
                $results[] = [
                    'index' => $idx,
                    'ok' => false,
                    'code' => 'not_an_object',
                    'error' => 'Each modules[] entry must be an object.',
                ];
                continue;
            }
            $mapped = self::map_module_params($entry, $defaultcourse);
            $warnings = self::module_entry_warnings($entry, $mapped);
            $refusal = self::refuse_module_entry($mapped);
            if ($refusal !== null) {
                $results[] = array_merge(['index' => $idx, 'ok' => false], $refusal, ['warnings' => $warnings]);
                continue;
            }
            try {
                $cm = self::run_as($actor, static function () use ($mapped) {
                    return course_writer::upsert_module($mapped);
                });
                $results[] = [
                    'index' => $idx,
                    'ok' => true,
                    'warnings' => $warnings,
                    'cmid' => (int)$cm->id,
                    'course' => (int)$cm->course,
                    'section' => isset($cm->section) ? (int)$cm->section : null,
                    'modname' => (string)$cm->modname,
                    'name' => isset($cm->name) ? (string)$cm->name : null,
                ];
            } catch (\Throwable $e) {
                $results[] = [
                    'index' => $idx,
                    'ok' => false,
                    'code' => $e instanceof \moodle_exception ? $e->errorcode : 'error',
                    'error' => self::exception_detail($e),
                    'warnings' => $warnings,
                ];
            }
        }

        // Batch semantics: a partly successful push is a 200 carrying the
        // per-entry outcome. When nothing at all could be written the caller
        // should be able to branch on the status alone, so say 4xx — that is
        // the single-module case, where an unsupported modname must trigger
        // their fallback rather than look like a success with details.
        $succeeded = count(array_filter($results, static function (array $r): bool {
            return !empty($r['ok']);
        }));
        $summary = [
            'total' => count($results),
            'ok' => $succeeded,
            'failed' => count($results) - $succeeded,
        ];
        if ($succeeded === 0) {
            return self::deny(422, ['results' => $results, 'summary' => $summary]);
        }
        return self::ok(['results' => $results, 'summary' => $summary]);
    }

    /**
     * Delete a list of course modules by their cmid.
     *
     * @param array $params
     * @return array
     */
    private static function action_delete_course_modules(array $params): array {
        $cmids = self::param($params, 'cmids', 'cmids');
        if (!is_array($cmids) || empty($cmids)) {
            return self::deny(400, ['error' => 'missing_cmids']);
        }
        try {
            $deleted = course_writer::delete_modules($cmids);
        } catch (\Throwable $e) {
            debugging('[block_alphabees] delete_course_modules failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return self::deny(500, ['error' => 'internal', 'detail' => $e->getMessage()]);
        }
        return self::ok(['deleted' => $deleted, 'count' => count($deleted)]);
    }

    /**
     * Completion write-back: set the activity-completion state of one user
     * for one course module.
     *
     * Uses Moodle's completion *override* — the same mechanism as the
     * "Override completion" action in the course completion report — so it
     * works for manual and automatic completion alike and is recorded with
     * overrideby = alphabees-service. Runs as the service user because
     * completion_info::update_state() checks moodle/course:overridecompletion
     * on the current $USER and api.php has no session.
     *
     * params: { cmid: int, userid: int, completed: bool, override_teacher?: bool }
     *     or  { cmid: int, userid: int, state: "complete" | "incomplete", ... }
     *
     * Only a state that is still empty or that Alphabees itself set is
     * changed (3.3.0), the same rule as for grades: a state a teacher
     * overrode is refused as teacher_modified, a result the learner reached
     * themselves (complete, passed or failed without an override) as
     * learner_result — unless override_teacher. A request for the state the
     * learner already has writes nothing and answers unchanged = true, so
     * a real completion is never turned into an override.
     *
     * Responses: 400 missing/invalid params, 404 cm/user unknown,
     * 409 completion_not_enabled | user_not_tracked (user has no active
     * enrolment counted in completion reports) | teacher_modified |
     * learner_result, 403 actor lacks capability (WS integration disabled and
     * no admin fallback), 200 with resulting state.
     *
     * @param array $params
     * @return array
     */
    private static function action_set_activity_completion(array $params): array {
        global $CFG, $DB;
        require_once($CFG->libdir . '/completionlib.php');

        $cmid = (int)(self::param($params, 'cmid', 'cmId') ?? self::param($params, 'cm_id', 'cmid') ?? 0);
        $userid = (int)(self::param($params, 'user_id', 'userId') ?? self::param($params, 'userid', 'userid') ?? 0);
        if ($cmid <= 0 || $userid <= 0) {
            return self::deny(400, ['error' => 'missing_cmid_or_userid']);
        }

        $completed = self::param($params, 'completed', 'completed');
        if ($completed === null) {
            $state = strtolower((string)(self::param($params, 'state', 'state')
                ?? self::param($params, 'new_state', 'newState') ?? ''));
            if ($state === 'complete' || $state === 'completed') {
                $completed = true;
            } else if ($state === 'incomplete') {
                $completed = false;
            } else {
                return self::deny(400, ['error' => 'missing_state']);
            }
        } else {
            $completed = self::truthy($completed);
        }
        $newstate = $completed ? COMPLETION_COMPLETE : COMPLETION_INCOMPLETE;

        $cm = get_coursemodule_from_id('', $cmid);
        if (!$cm) {
            return self::deny(404, ['error' => 'cm_not_found']);
        }
        if (!$DB->record_exists('user', ['id' => $userid, 'deleted' => 0])) {
            return self::deny(404, ['error' => 'user_not_found']);
        }

        try {
            $course = get_course((int)$cm->course);
            $completion = new \completion_info($course);
            if (!$completion->is_enabled($cm)) {
                return self::deny(409, ['error' => 'completion_not_enabled']);
            }
            if (!$completion->is_tracked_user($userid)) {
                return self::deny(409, ['error' => 'user_not_tracked']);
            }

            $actor = self::actor_user();
            if (!$actor) {
                return self::deny(403, ['error' => 'no_actor_user']);
            }
            if (!$completion->user_can_override_completion($actor)) {
                return self::deny(403, ['error' => 'actor_lacks_overridecompletion']);
            }

            $current = $completion->get_data($cm, false, $userid);
            $refusal = self::completion_refusal(
                $current,
                $completed,
                (int)$actor->id,
                self::truthy(self::param_any($params, ['override_teacher', 'overrideTeacher']) ?? false)
            );
            if ($refusal === 'unchanged') {
                $data = $current;
            } else if ($refusal !== null) {
                return self::deny(409, [
                    'error' => $refusal,
                    'completionstate' => (int)$current->completionstate,
                    'overrideby' => (int)($current->overrideby ?? 0),
                ]);
            } else {
                $data = self::run_as($actor, function () use ($completion, $cm, $userid, $newstate) {
                    $completion->update_state($cm, $newstate, $userid, true);
                    return $completion->get_data($cm, false, $userid);
                });
            }
        } catch (\Throwable $e) {
            debugging('[block_alphabees] set_activity_completion failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return self::deny(500, ['error' => 'internal', 'detail' => $e->getMessage()]);
        }

        $resultstate = (int)($data->completionstate ?? COMPLETION_INCOMPLETE);
        return self::ok([
            'cmid' => $cmid,
            'userid' => $userid,
            'courseid' => (int)$cm->course,
            'completionstate' => $resultstate,
            'completed' => $resultstate !== COMPLETION_INCOMPLETE,
            'overrideby' => (int)($data->overrideby ?? 0),
            'timemodified' => (int)($data->timemodified ?? 0),
            'unchanged' => $refusal === 'unchanged',
            'previousstate' => (int)$current->completionstate,
        ]);
    }

    /**
     * Whether a completion state may be replaced by the one requested.
     *
     * @param \stdClass $current The learner's completion data for the cm.
     * @param bool $completed The requested state.
     * @param int $actorid The account Alphabees writes as.
     * @param bool $override Replace a state someone else set.
     * @return string|null null to write, 'unchanged' when the learner already
     *         has that state, else the refusal code.
     */
    private static function completion_refusal(\stdClass $current, bool $completed, int $actorid, bool $override): ?string {
        $state = (int)$current->completionstate;
        $done = in_array($state, [COMPLETION_COMPLETE, COMPLETION_COMPLETE_PASS], true);
        if ($completed ? $done : $state === COMPLETION_INCOMPLETE) {
            return 'unchanged';
        }
        if ($override) {
            return null;
        }
        $overrideby = (int)($current->overrideby ?? 0);
        if ($overrideby > 0 && $overrideby !== $actorid) {
            return 'teacher_modified';
        }
        if ($overrideby === 0 && $state !== COMPLETION_INCOMPLETE) {
            return 'learner_result';
        }
        return null;
    }

    /**
     * Write learners' results into an Alphabees grade item, creating it if needed.
     *
     * params: { courseid, ref, item?: {name, grademax, gradepass, category,
     * hidden}, grades?: [{userid, grade|null, feedback?}], override_teacher? }
     *
     * Only items with the idnumber alphabees:<ref> are touched (grade_writer).
     * 200 when the item was written and at least one grade (or none were sent),
     * 422 when every grade was refused — each entry says why.
     *
     * @param array $params
     * @return array
     */
    private static function action_set_grades(array $params): array {
        global $DB;
        $courseid = (int)(self::param_any($params, param_schema::COURSE_ALIASES) ?? 0);
        $ref = (string)(self::param_any($params, ['ref', 'item_ref', 'itemRef']) ?? '');
        if ($courseid <= 0 || $ref === '') {
            return self::deny(400, ['error' => 'missing_courseid_or_ref']);
        }
        if ($courseid == SITEID || !$DB->record_exists('course', ['id' => $courseid])) {
            return self::deny(404, ['error' => 'course_not_found']);
        }
        $definition = self::param($params, 'item', 'item');
        $definition = is_array($definition) ? $definition : [];
        $grades = self::param($params, 'grades', 'grades');
        $grades = is_array($grades) ? array_values($grades) : [];
        $override = self::truthy(self::param_any($params, ['override_teacher', 'overrideTeacher']) ?? false);

        $actor = self::actor_user();
        if (!$actor) {
            return self::deny(403, ['error' => 'no_actor_user']);
        }
        try {
            [$item, $results] = self::run_as($actor, function () use ($courseid, $ref, $definition, $grades, $actor, $override) {
                $item = grade_writer::ensure_item($courseid, $ref, $definition);
                return [$item, grade_writer::write($item, $grades, (int)$actor->id, $override)];
            });
        } catch (\invalid_parameter_exception $e) {
            return self::deny(400, ['error' => 'invalid_item', 'detail' => self::exception_detail($e)]);
        } catch (\Throwable $e) {
            debugging('[block_alphabees] set_grades failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return self::deny(500, ['error' => 'internal', 'detail' => self::exception_detail($e)]);
        }

        $written = count(array_filter($results, static function (array $r): bool {
            return $r['ok'];
        }));
        $body = [
            'item' => grade_writer::describe($item),
            'results' => $results,
            'summary' => ['total' => count($results), 'ok' => $written, 'failed' => count($results) - $written],
        ];
        if ($results && !$written) {
            return self::deny(422, ['error' => 'no_grade_written'] + $body);
        }
        return self::ok($body);
    }

    /**
     * The Alphabees grade items of a course.
     *
     * @param array $params courseid.
     * @return array
     */
    private static function action_list_grade_items(array $params): array {
        global $DB;
        $courseid = (int)(self::param_any($params, param_schema::COURSE_ALIASES) ?? 0);
        if ($courseid <= 0) {
            return self::deny(400, ['error' => 'missing_courseid']);
        }
        if (!$DB->record_exists('course', ['id' => $courseid])) {
            return self::deny(404, ['error' => 'course_not_found']);
        }
        return self::ok([
            'courseid' => $courseid,
            'items' => array_map([grade_writer::class, 'describe'], grade_writer::items($courseid)),
        ]);
    }

    /**
     * Remove an Alphabees grade item and the grades in it.
     *
     * @param array $params courseid, ref.
     * @return array
     */
    private static function action_delete_grade_item(array $params): array {
        $courseid = (int)(self::param_any($params, param_schema::COURSE_ALIASES) ?? 0);
        $ref = (string)(self::param_any($params, ['ref', 'item_ref', 'itemRef']) ?? '');
        if ($courseid <= 0 || $ref === '') {
            return self::deny(400, ['error' => 'missing_courseid_or_ref']);
        }
        $item = grade_writer::find_item($courseid, $ref);
        if (!$item) {
            return self::deny(404, ['error' => 'grade_item_not_found']);
        }
        $actor = self::actor_user();
        if (!$actor) {
            return self::deny(403, ['error' => 'no_actor_user']);
        }
        self::run_as($actor, function () use ($item) {
            $item->delete(grade_writer::SOURCE);
        });
        return self::ok(['courseid' => $courseid, 'ref' => $ref, 'deleted' => true]);
    }

    /**
     * User account inbound write actions run as when Moodle APIs check $USER.
     *
     * Prefers the alphabees-service user (manager role at system context),
     * falls back to the primary admin when the WS integration was never
     * enabled on this site.
     *
     * @return \stdClass|null
     */
    private static function actor_user(): ?\stdClass {
        global $DB;
        $actor = $DB->get_record('user', ['username' => ws_setup::SERVICE_USERNAME, 'deleted' => 0]);
        if (!$actor) {
            $actor = get_admin() ?: null;
        }
        return $actor ?: null;
    }

    /**
     * Run a callback with $USER temporarily switched to the given account.
     *
     * api.php runs without a session (NO_MOODLE_COOKIES), so $USER is the
     * not-logged-in stub; core APIs that capability-check the current user
     * need a real actor. The previous $USER is restored afterwards.
     *
     * @param \stdClass $user
     * @param callable $fn
     * @return mixed
     */
    private static function run_as(\stdClass $user, callable $fn) {
        global $USER;
        $previous = $USER;
        \core\session\manager::set_user($user);
        try {
            return $fn();
        } finally {
            if ($previous instanceof \stdClass) {
                try {
                    \core\session\manager::set_user($previous);
                } catch (\Throwable $e) {
                    $USER = $previous;
                }
            }
        }
    }

    /**
     * Translate the inbound course params (snake/camel mix) to the keys
     * course_writer::upsert_course expects.
     *
     * @param array $params
     * @return array
     */
    private static function map_course_params(array $params): array {
        $map = [
            'id' => self::param($params, 'id', 'id'),
            'shortname' => self::param($params, 'shortname', 'shortname'),
            'fullname' => self::param($params, 'fullname', 'fullname'),
            'summary' => self::param($params, 'summary', 'summary'),
            'summaryformat' => self::param($params, 'summary_format', 'summaryFormat'),
            'format' => self::param($params, 'format', 'format'),
            'category' => self::param($params, 'category_id', 'categoryId') ?? self::param($params, 'category', 'category'),
            'visible' => self::param($params, 'visible', 'visible'),
            'numsections' => self::param($params, 'num_sections', 'numSections'),
        ];
        // Strip nulls so course_writer treats them as "not provided".
        return array_filter($map, function ($v) {
            return $v !== null;
        });
    }

    /**
     * Name the reason a module entry cannot be written, before course_writer
     * turns it into a generic "invalidparameter".
     *
     * The writer's message is a language string; its explanation lives in
     * debuginfo, which Moodle suppresses outside PHPUnit. A caller therefore
     * saw the same opaque error whether the course id, the modname or both
     * were missing. These two checks are the ones a caller can act on, so they
     * answer in the caller's own terms and name the accepted values.
     *
     * @param array $mapped Output of map_module_params().
     * @return array|null ['code' => ..., 'error' => ...], or null when usable.
     */
    private static function refuse_module_entry(array $mapped): ?array {
        if (!empty($mapped['cmid'])) {
            // Update path: the cm carries its own course and type.
            return null;
        }
        if (empty($mapped['course'])) {
            return [
                'code' => 'missing_course',
                'error' => 'No course id. Pass course_id once next to modules, or per entry.',
            ];
        }
        if (empty($mapped['modname'])) {
            return [
                'code' => 'missing_modname',
                'error' => 'No modname. Supported: ' . implode(', ', course_writer::SUPPORTED_MODNAMES) . '.',
            ];
        }
        return null;
    }

    /**
     * Normalise the upload params to the keys file_uploader::upload() reads.
     *
     * Same rule as everywhere else on this channel: a caller may spell a
     * parameter snake_case or camelCase. file_uploader reads the internal
     * spelling only, so a `fileName` arrived as no filename at all and the
     * upload was refused for a field the caller had in fact sent.
     *
     * @param array $params
     * @return array
     */
    private static function map_upload_params(array $params): array {
        $aliases = [
            'filename' => ['filename', 'fileName', 'file_name'],
            'content' => ['content', 'content_base64', 'contentBase64'],
            'itemid' => ['itemid', 'itemId', 'item_id', 'draftitemid', 'draftItemId', 'draft_item_id'],
            'filepath' => ['filepath', 'filePath', 'file_path'],
            'contentisbase64' => ['contentisbase64', 'contentIsBase64', 'content_is_base64'],
        ];
        $map = [];
        foreach ($aliases as $key => $spellings) {
            $value = self::param_any($params, $spellings);
            if ($value !== null) {
                $map[$key] = $value;
            }
        }
        return $map;
    }

    /**
     * Translate inbound module params to course_writer::upsert_module keys.
     *
     * Reads param_schema rather than a list of its own. The previous
     * hand-written allowlist had to be kept in step with course_writer by hand
     * and twice was not, each time dropping a parameter the caller had sent.
     *
     * @param array $entry One element of the inbound `modules` array.
     * @param mixed $defaultcourse Course id given once for the whole batch,
     *                             used for entries that name none themselves.
     * @return array
     */
    private static function map_module_params(array $entry, $defaultcourse = null): array {
        $map = [];
        foreach (param_schema::MODULE_PARAMS as $key => $declaration) {
            $value = self::param_any($entry, $declaration['accepts']);
            if ($value !== null) {
                $map[$key] = $value;
            }
        }
        // An entry may name its own course; otherwise the batch-level one
        // applies. Core web services spell this courseid, our other course
        // actions spell it course_id — accept both rather than refuse over an
        // underscore.
        $course = self::param_any($entry, param_schema::COURSE_ALIASES) ?? $defaultcourse;
        if ($course !== null) {
            $map['course'] = $course;
        }
        return $map;
    }

    /**
     * Report what an entry sent that will have no effect.
     *
     * Dropping an unrecognised parameter in silence is how both of the import
     * failures behaved, so the caller is told instead. These are warnings, not
     * errors: a spelling we do not know must not stop a module being written,
     * or a caller that sends one harmless extra field would be unable to
     * publish at all.
     *
     * @param array $entry The raw inbound entry.
     * @param array $mapped The recognised subset.
     * @return string[] Human-readable notes, empty when nothing is odd.
     */
    private static function module_entry_warnings(array $entry, array $mapped): array {
        $warnings = [];
        foreach (array_keys($entry) as $given) {
            if (param_schema::internal_key((string)$given) === null) {
                $warnings[] = "Unknown parameter '{$given}' was ignored.";
            }
        }
        $modname = isset($mapped['modname']) ? (string)$mapped['modname'] : '';
        if ($modname !== '') {
            $accepted = param_schema::keys_for($modname);
            foreach (array_keys($mapped) as $key) {
                if ($key !== 'course' && !in_array($key, $accepted, true)) {
                    $warnings[] = "Parameter '{$key}' is not read by {$modname} and had no effect.";
                }
            }
        }
        return $warnings;
    }

    /**
     * Shape a Moodle course row into the response payload format.
     *
     * @param \stdClass $course
     * @return array
     */
    private static function shape_course(\stdClass $course): array {
        return [
            'id' => (int)$course->id,
            'shortname' => (string)$course->shortname,
            'fullname' => (string)$course->fullname,
            'category' => (int)$course->category,
            'visible' => (bool)$course->visible,
            'format' => (string)$course->format,
            'summary' => (string)$course->summary,
            'summary_format' => (int)$course->summaryformat,
        ];
    }

    /**
     * Look up a parameter under either of two key spellings.
     *
     * The backend may serialize action params as snake_case (Pydantic default)
     * or camelCase (ResponseVM mapper convention). Accept either so we don't
     * silently drop parameters from one side or the other.
     */
    private static function param(array $params, string $snake, string $camel) {
        if (array_key_exists($snake, $params)) {
            return $params[$snake];
        }
        if (array_key_exists($camel, $params)) {
            return $params[$camel];
        }
        return null;
    }

    /**
     * Read the first of several accepted spellings of one parameter.
     *
     * param() takes exactly two, which is enough where we control both ends.
     * The course id is not such a case: upsert_course and upsert_section have
     * always taken it as course_id, core's own web services spell it courseid,
     * and a caller reasonably tries either.
     *
     * @param array $params
     * @param string[] $keys Accepted spellings, in order of preference.
     * @return mixed|null Null when none of them is present.
     */
    private static function param_any(array $params, array $keys) {
        foreach ($keys as $key) {
            if (array_key_exists($key, $params)) {
                return $params[$key];
            }
        }
        return null;
    }

    /**
     * Failure detail for one entry of a batch, including the debuginfo that a
     * moodle_exception keeps out of getMessage() outside PHPUnit.
     *
     * Without it the caller is told "Invalid parameter value detected" and has
     * no way to learn which parameter — which is exactly the position the
     * course generator was left in when upsert_modules refused every module.
     *
     * @param \Throwable $e
     * @return string
     */
    private static function exception_detail(\Throwable $e): string {
        $detail = $e->getMessage();
        if ($e instanceof \moodle_exception && !empty($e->debuginfo)) {
            $detail .= ' (' . $e->debuginfo . ')';
        }
        return $detail;
    }

    /**
     * Return the first non-empty string value found under any of the given keys.
     *
     * @param array $params
     * @param array $keys
     * @return string
     */
    private static function string_param_any(array $params, array $keys): string {
        foreach ($keys as $key) {
            if (isset($params[$key]) && is_scalar($params[$key]) && (string)$params[$key] !== '') {
                return clean_param((string)$params[$key], PARAM_TEXT);
            }
        }
        return '';
    }

    /**
     * Run a console handler, turning refusals into an envelope.
     *
     * The console bridge expects every answer in the same shape, so a missing
     * record or a learner who is not in this course comes back as a refusal
     * with a code rather than as an exception the caller has to special-case.
     *
     * @param caller $caller
     * @param string $action
     * @param array $params
     * @return array
     */
    private static function run_console_action(caller $caller, string $action, array $params): array {
        try {
            switch ($action) {
                case 'console_context':
                    return self::ok(console_actions::context($caller));
                case 'get_learner_overview':
                    return self::ok(console_actions::learner_overview($caller, $params));
                case 'send_user_message':
                    return console_actions::send_user_message($caller, $params);
                default:
                    return self::deny(404);
            }
        } catch (\required_capability_exception $e) {
            return self::deny(403, ['code' => 'capability_required']);
        } catch (\moodle_exception $e) {
            return self::deny(400, ['code' => $e->errorcode]);
        }
    }

    /**
     * Describe the Generico filter templates configured on this site.
     *
     * Generico has no web-service functions, and a web-service read of course
     * content returns the expanded output, never the tag, so this is the only
     * way for the backend to learn which {GENERICO:...} tags exist and what
     * they take. See local\generico_reader.
     *
     * @param array $params Optionally keys[], include_bodies (default true), course_id.
     * @return array
     */
    private static function action_list_generico_templates(array $params): array {
        $keys = self::param($params, 'keys', 'templateKeys') ?? self::param($params, 'template_keys', 'templatekeys');
        $keys = is_array($keys) ? array_map(static fn($k) => clean_param((string)$k, PARAM_ALPHANUMEXT), $keys) : [];
        $bodies = self::param($params, 'include_bodies', 'includeBodies');
        $courseid = (int)(self::param($params, 'course_id', 'courseId') ?? 0);
        return self::ok(generico_reader::describe($keys, $bodies === null || !empty($bodies), $courseid));
    }

    /**
     * Activities and sections one learner cannot open in one course.
     *
     * Moodle evaluates every rule for that learner (see user_access), so the
     * backend can keep restricted material out of what the agent searches and
     * says. courseid and userid are echoed so a caller can discard an answer
     * meant for someone else.
     *
     * @param array $params courseid and userid, both required.
     * @return array
     */
    private static function action_get_user_access(array $params): array {
        global $DB;
        $courseid = (int)(self::param_any($params, param_schema::COURSE_ALIASES) ?? 0);
        $userid = (int)(self::param_any($params, param_schema::USER_ALIASES) ?? 0);
        if ($courseid <= 0 || $userid <= 0) {
            return self::deny(400, ['error' => 'missing_params']);
        }
        $user = \core_user::get_user($userid, 'id, deleted', IGNORE_MISSING);
        if (!$user || $user->deleted) {
            return self::deny(404, ['error' => 'user_not_found']);
        }
        $course = $DB->get_record('course', ['id' => $courseid]);
        if (!$course) {
            return self::deny(404, ['error' => 'course_not_found']);
        }
        return self::ok(['courseid' => $courseid, 'userid' => $userid] + user_access::blocked($course, $userid));
    }

    /**
     * The readable text of the activity a learner has open (see activity_text).
     *
     * Read as that learner, so their access rules and filters apply. A
     * refusal is an answer, not a transport error: 200 with ok = false and
     * one of the fixed codes, never an empty text. Only missing parameters
     * (400), an unknown module or user (404) and an exception (500,
     * retryable) use an error status.
     *
     * @param array $params cmid, userid, optionally pageid, chapterid, max_chars.
     * @return array
     */
    private static function action_get_activity_text(array $params): array {
        $cmid = (int)(self::param_any($params, ['cmid', 'cmId', 'cm_id']) ?? 0);
        $userid = (int)(self::param_any($params, param_schema::USER_ALIASES) ?? 0);
        if ($cmid <= 0) {
            return self::deny(400, ['error' => 'missing_cmid']);
        }
        if ($userid <= 0) {
            return self::deny(400, ['error' => 'missing_userid']);
        }
        $user = \core_user::get_user($userid, '*', IGNORE_MISSING);
        if (!$user || $user->deleted) {
            return self::deny(404, ['error' => 'user_not_found']);
        }
        $pageid = (int)(self::param_any($params, ['pageid', 'pageId', 'page_id']) ?? 0);
        $chapterid = (int)(self::param_any($params, ['chapterid', 'chapterId', 'chapter_id']) ?? 0);
        $maxchars = (int)(self::param_any($params, ['max_chars', 'maxChars', 'maxchars']) ?? 0);

        try {
            $result = self::run_as($user, function () use ($cmid, $userid, $pageid, $chapterid, $maxchars) {
                return activity_text::read($cmid, $userid, $pageid, $chapterid, $maxchars);
            });
        } catch (\Throwable $e) {
            debugging('[block_alphabees] get_activity_text failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return self::deny(500, ['error' => 'internal', 'cmid' => $cmid, 'retryable' => true]);
        }
        if (!isset($result['error'])) {
            return self::ok($result);
        }
        return self::deny($result['error'] === 'module_not_found' ? 404 : 200, $result);
    }

    /**
     * Report which H5P libraries this site has installed.
     *
     * A content-only .h5p package — h5p.json plus content/, without the
     * library folders — is only importable when every preloaded dependency is
     * already present at a matching major.minor version. Moodle ships none of
     * them: they arrive when an admin fetches content types from the H5P hub
     * or uploads a full package once. Rather than have the generator guess
     * versions and find out through a failed import, let it ask.
     *
     * @param array $params Optionally machinenames[] to narrow the answer.
     * @return array
     */
    private static function action_list_h5p_libraries(array $params): array {
        global $DB;

        if (!$DB->get_manager()->table_exists('h5p_libraries')) {
            return self::ok(['available' => false, 'libraries' => []]);
        }

        $conditions = [];
        $names = self::param($params, 'machinenames', 'machineNames');
        if (is_array($names) && !empty($names)) {
            $clean = array_values(array_filter(array_map(static function ($n) {
                return clean_param((string)$n, PARAM_ALPHANUMEXT);
            }, $names)));
            if (!empty($clean)) {
                $conditions['machinename'] = $clean;
            }
        }

        if (isset($conditions['machinename'])) {
            [$insql, $inparams] = $DB->get_in_or_equal($conditions['machinename'], SQL_PARAMS_NAMED, 'mn');
            $records = $DB->get_records_select(
                'h5p_libraries',
                'machinename ' . $insql,
                $inparams,
                'machinename ASC, majorversion ASC, minorversion ASC'
            );
        } else {
            $records = $DB->get_records(
                'h5p_libraries',
                null,
                'machinename ASC, majorversion ASC, minorversion ASC'
            );
        }

        $libraries = [];
        foreach ($records as $row) {
            $libraries[] = [
                'machinename' => (string)$row->machinename,
                'title' => (string)($row->title ?? ''),
                'major' => (int)$row->majorversion,
                'minor' => (int)$row->minorversion,
                'patch' => (int)$row->patchversion,
                'version' => (int)$row->majorversion . '.' . (int)$row->minorversion,
                'runnable' => !empty($row->runnable),
                'enabled' => !isset($row->enabled) || !empty($row->enabled),
            ];
        }

        return self::ok([
            'available' => true,
            'count' => count($libraries),
            'libraries' => $libraries,
        ]);
    }

    /**
     * Store one file in a draft area so a later module can reference it.
     *
     * Runs as the service user because draft areas live in a user context and
     * upsert_modules resolves them as that same account.
     *
     * @param array $params
     * @return array
     */
    private static function action_upload_file(array $params): array {
        $actor = self::actor_user();
        if (!$actor) {
            return self::deny(403, ['error' => 'no_actor_user']);
        }
        $upload = self::map_upload_params($params);
        try {
            $result = self::run_as($actor, static function () use ($upload) {
                return file_uploader::upload($upload);
            });
            return self::ok($result);
        } catch (\moodle_exception $e) {
            return self::deny(400, ['code' => $e->errorcode, 'error' => $e->getMessage()]);
        } catch (\Throwable $e) {
            return self::deny(500, ['error' => 'upload_failed']);
        }
    }

    /**
     * Deliver a backend-triggered notification to a course's responsible staff.
     *
     * The heavy lifting — recipient verification, dedup, message building —
     * lives in {@see notifier}; this only shapes the response envelope.
     *
     * @param array $params
     * @return array
     */
    private static function action_notify(array $params): array {
        try {
            return self::ok(notifier::send($params));
        } catch (\moodle_exception $e) {
            return self::deny(400, ['code' => $e->errorcode]);
        }
    }

    /**
     * Accept canonical action names and lifecycle aliases from the portal.
     *
     * @param array $body
     * @return string
     */
    private static function normalise_action(array $body): string {
        $raw = '';
        foreach (['action', 'event_type', 'event'] as $key) {
            if (isset($body[$key]) && is_string($body[$key])) {
                $raw = strtolower(trim($body[$key]));
                break;
            }
        }

        switch ($raw) {
            case 'pause':
            case 'paused':
            case 'site.paused':
                return 'pause_site';
            case 'resume':
            case 'resumed':
            case 'site.resumed':
                return 'resume_site';
            case 'disconnect':
            case 'disconnected':
            case 'site.disconnected':
                return 'disconnect_site';
            default:
                return $raw;
        }
    }

    /**
     * Drop queued lifecycle events superseded by an inbound portal action.
     *
     * @param string $eventtype
     * @return void
     */
    private static function drop_queued_lifecycle_event(string $eventtype): void {
        global $DB;

        try {
            $rows = $DB->get_records('block_alphabees_retryqueue', [
                'endpoint' => site_registry::path_lifecycle(),
            ]);
            foreach ($rows as $row) {
                $payload = json_decode((string)$row->payload, true);
                if (
                    is_array($payload)
                    && isset($payload['event_type'])
                    && (string)$payload['event_type'] === $eventtype
                ) {
                    $DB->delete_records('block_alphabees_retryqueue', ['id' => $row->id]);
                }
            }
        } catch (\Throwable $e) {
            debugging('[block_alphabees] inbound resume queue cleanup failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * Interpret inbound boolean-like params consistently.
     *
     * @param mixed $value
     * @return bool
     */
    private static function truthy($value): bool {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value)) {
            return $value === 1;
        }
        if (is_string($value)) {
            return in_array(strtolower($value), ['1', 'true', 'yes', 'on'], true);
        }
        return false;
    }

    // Response helpers.

    /**
     * Build a 200 OK response envelope.
     *
     * @param array $body
     * @return array
     */
    private static function ok(array $body): array {
        return ['httpStatus' => 200, 'body' => array_merge(['ok' => true], $body)];
    }

    /**
     * Build a non-2xx response envelope with the given status.
     *
     * @param int $status
     * @param array $body
     * @return array
     */
    private static function deny(int $status, array $body = []): array {
        return ['httpStatus' => $status, 'body' => array_merge(['ok' => false], $body)];
    }
}
