// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Main AMD module for loading and initializing the Alphabees Chat Widget.
 *
 * @package   block_alphabees
 * @copyright 2025 Alphabees
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define([
    'block_alphabees/config',
    'al-chat-widget'
], function (config, externalIgnore) {
    "use strict";

    const _loadAlChat = window._loadAlChat;

    return {
        /**
         * Initialize the chat widget with API key, bot ID, primary color, and context.
         *
         * @param {string} apiKey API key for Alphabees.
         * @param {string} botId Bot identifier.
         * @param {string} primaryColor Primary color hex (e.g., "#72AECF").
         * @param {{courseid:number, sectionnum:number, sectionid:number, userid:number}} ctx Context data.
         */
        init: function (apiKey, botId, primaryColor, ctx) {
            if (typeof _loadAlChat !== "function") {
                window.console && console.error("[alphabees] _loadAlChat is not defined.");
                return;
            }
            try {
                const currentSessionId = function () {
                    const state = window.alphabees && window.alphabees.state ? window.alphabees.state : null;
                    if (!state) {
                        return "";
                    }
                    return String(state.sessionId || state.session_id || state.conversationId || state.conversation_id || "");
                };
                const emitMoodleContextEvent = function (payload, reason, previousCourseId) {
                    const eventPayload = {
                        eventType: "moodle.context.changed",
                        reason: reason || "init",
                        occurredAt: new Date().toISOString(),
                        activeSession: !!(window.alphabees && window.alphabees.state),
                        sessionId: currentSessionId(),
                        data: payload
                    };
                    if (typeof previousCourseId === "number") {
                        eventPayload.previousCourseId = previousCourseId;
                    }
                    window.postMessage({ type: "alMoodleContextChanged", data: eventPayload }, "*");
                    if (typeof window.CustomEvent === "function") {
                        window.dispatchEvent(new CustomEvent("alphabees:moodle-context-changed", {
                            detail: eventPayload
                        }));
                    }
                };
                const userId = Number((ctx && ctx.userid) || 0) || 0;
                const context = {
                    courseId: Number((ctx && ctx.courseid) || 0) || 0,
                    courseName: (ctx && ctx.coursename) ? String(ctx.coursename) : "",
                    courseShortname: (ctx && ctx.courseshortname) ? String(ctx.courseshortname) : "",
                    sectionId: Number((ctx && ctx.sectionid) || 0) || 0,
                    sectionNum: Number((ctx && ctx.sectionnum) || 0) || 0,
                    contextId: Number((ctx && ctx.contextid) || 0) || 0,
                    contextLevel: Number((ctx && ctx.contextlevel) || 0) || 0,
                    pageType: (ctx && ctx.pagetype) ? String(ctx.pagetype) : "",
                    pageUrl: (ctx && ctx.pageurl) ? String(ctx.pageurl) : window.location.href,
                    cmid: Number((ctx && ctx.cmid) || 0) || 0,
                    modType: (ctx && ctx.modtype) ? String(ctx.modtype) : "",
                    activityId: Number((ctx && ctx.activityid) || 0) || 0,
                    activityName: (ctx && ctx.activityname) ? String(ctx.activityname) : ""
                };
                const placementUuid = (ctx && ctx.placementuuid) ? String(ctx.placementuuid) : "";
                const siteIdentifier = (ctx && ctx.siteidentifier) ? String(ctx.siteidentifier) : "";
                const payload = {
                    apiKey: apiKey,
                    botId: botId,
                    primaryColor: primaryColor,
                    development: false,
                    platform: "moodle",
                    userId: userId,
                    context: context,
                    placementUuid: placementUuid,
                    siteIdentifier: siteIdentifier
                };
                // Opt-in user profile (site setting send_userprofile): first
                // name only, top-level like userId — never inside 'context'.
                if (ctx && ctx.userprofile && ctx.userprofile.firstName) {
                    payload.userProfile = { firstName: String(ctx.userprofile.firstName) };
                }

                // This Moodle session, as sha256(sesskey|wwwroot). The plugin
                // reports the same hash when the user logs out, so al-tutor can
                // end the tutor session. Stable for the session, so it stays in
                // the navigation pushes too.
                if (ctx && ctx.sessionhash) {
                    payload.sessionHash = String(ctx.sessionhash);
                }

                // Deep link from a Moodle notification: open this exercise or
                // thread. Top-level like userId, deliberately not inside
                // 'context' — it is an instruction to the UI, not material for
                // the agent's prompt.
                if (ctx && ctx.deeplink) {
                    payload.deepLink = String(ctx.deeplink);
                }

                window.console && console.log("[alphabees] Initializing chat widget…", { userId, context, placementUuid, siteIdentifier });

                window.__alphabeesMoodleLastPayload = payload;
                _loadAlChat(payload);
                window.postMessage({ type: "alUpdateState", data: payload }, "*");
                emitMoodleContextEvent(payload, "init");

                // Every Moodle page load runs init again, so the full payload
                // above already goes out on each page. A different course than
                // on the previous page in this tab additionally gets its own
                // event naming the course it came from. sessionStorage, because
                // a page load starts a fresh window; it may be unavailable.
                let previousCourseId = null;
                try {
                    const stored = window.sessionStorage.getItem("alphabees:lastCourseId");
                    previousCourseId = stored === null ? null : (Number(stored) || 0);
                    window.sessionStorage.setItem("alphabees:lastCourseId", String(context.courseId));
                } catch (e) {
                    previousCourseId = null;
                }
                if (previousCourseId !== null && previousCourseId !== context.courseId) {
                    emitMoodleContextEvent(payload, "course_changed", previousCourseId);
                }

                if (!window.__alphabeesMoodleContextWatcher) {
                    window.__alphabeesMoodleContextWatcher = true;
                    const pushLatestState = function () {
                        const latest = window.__alphabeesMoodleLastPayload;
                        if (!latest) {
                            return;
                        }
                        latest.context = latest.context || {};
                        latest.context.pageUrl = window.location.href;
                        // The name never changes within a session — sent once
                        // at init, omitted from navigation pushes.
                        const navPayload = Object.assign({}, latest);
                        delete navPayload.userProfile;
                        // Same for the deep link: acting on it once is the
                        // point, reopening it on every page change is not.
                        delete navPayload.deepLink;
                        window.postMessage({ type: "alUpdateState", data: navPayload }, "*");
                        emitMoodleContextEvent(navPayload, "navigation");
                    };
                    ["pushState", "replaceState"].forEach(function (method) {
                        const original = window.history && window.history[method];
                        if (typeof original !== "function") {
                            return;
                        }
                        window.history[method] = function () {
                            const result = original.apply(this, arguments);
                            window.setTimeout(pushLatestState, 0);
                            return result;
                        };
                    });
                    window.addEventListener("popstate", pushLatestState);
                    window.addEventListener("hashchange", pushLatestState);
                }
            } catch (e) {
                window.console && console.error("[alphabees] Init error:", e);
            }
        }
    };
});
