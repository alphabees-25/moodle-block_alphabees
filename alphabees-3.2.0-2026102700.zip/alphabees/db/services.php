<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External service definition for the Alphabees AI Tutor block plugin.
 *
 * Pre-declares an external service with shortname `block_alphabees` so the
 * plugin's auto-setup flow only needs to enable web-services + REST and
 * generate a token — no manual service creation.
 *
 * The function list bundles the standard Moodle core functions the
 * Alphabees backend uses to read course / module / enrolment data, plus
 * the writeable functions used during course-export (Option B in the
 * legacy setup guide). Customers who don't want export simply ignore the
 * write paths — Moodle gates each function by capability, not by
 * service-membership.
 *
 * @package   block_alphabees
 * @copyright 2026 Alphabees
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// The display name intentionally differs from the bare "Alphabees" used by
// the legacy 11-step manual setup guide. external_services.name is unique-
// indexed, and many existing customer sites still have a manually-created
// 'Alphabees' service from before this plugin shipped its auto-setup. Using
// a distinct name here lets the plugin install on those sites without
// hitting a duplicate-key violation; the manual service can stay until the
// admin removes it themselves.
// Plugin-own external functions. Data-minimised by design: they return
// counts, timestamps and titles only — never post content or author names —
// so the backend can serve "what is new / what is due" questions without
// personal data of other participants leaving Moodle.
$functions = [
    'block_alphabees_get_forum_activity' => [
        'classname' => 'block_alphabees\\external\\get_forum_activity',
        'methodname' => 'execute',
        'description' => 'Anonymised forum activity metadata (counts and timestamps only) '
            . 'for the forums a given user can see.',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_get_user_calendar' => [
        'classname' => 'block_alphabees\\external\\get_user_calendar',
        'methodname' => 'execute',
        'description' => 'Personal calendar view of a given user (site, course, group and user '
            . 'events incl. per-user overrides) for a service-token caller.',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_get_course_completions' => [
        'classname' => 'block_alphabees\\external\\get_course_completions',
        'methodname' => 'execute',
        'description' => 'Completion percentage and state for every tracked user of one course '
            . '(one call per course).',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_get_quiz_questions' => [
        'classname' => 'block_alphabees\\external\\get_quiz_questions',
        'methodname' => 'execute',
        'description' => 'All questions of one quiz incl. answers, fractions and feedback as '
            . 'structured data (knowledge-base ingestion; requires moodle/question:viewall).',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_discover_progress_sources' => [
        'classname' => 'block_alphabees\\external\\discover_progress_sources',
        'methodname' => 'execute',
        'description' => 'Which progress sources the site has (course completion, Completion Progress, '
            . 'competencies), in counts only.',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_get_progress_trackers' => [
        'classname' => 'block_alphabees\\external\\get_progress_trackers',
        'methodname' => 'execute',
        'description' => 'Completion Progress bars of one course and each learner\'s state on them, '
            . 'one page of learners per call.',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_get_rendered_course_texts' => [
        'classname' => 'block_alphabees\\external\\get_rendered_course_texts',
        'methodname' => 'execute',
        'description' => 'Course texts containing filter tags, rendered as a learner\'s page shows them, '
            . 'for a neutral viewer.',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_get_course_grades' => [
        'classname' => 'block_alphabees\\external\\get_course_grades',
        'methodname' => 'execute',
        'description' => 'Each learner\'s user grade report as they see it, one page of learners per call.',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_get_course_fields' => [
        'classname' => 'block_alphabees\\external\\get_course_fields',
        'methodname' => 'execute',
        'description' => 'Course custom fields with their visibility and displayed value.',
        'type' => 'read',
        'ajax' => false,
    ],
    'block_alphabees_describe_functions' => [
        'classname' => 'block_alphabees\\external\\describe_functions',
        'methodname' => 'execute',
        'description' => 'JSON Schemas of the parameters and return values of every function in this service.',
        'type' => 'read',
        'ajax' => false,
    ],

    // The console's entrance into the action registry, called from the browser
    // of a signed-in user. Deliberately absent from the service below: a
    // web-service token must not reach it, because this is the one path that
    // runs with the calling person's own capabilities rather than the service
    // user's manager rights.
    'block_alphabees_console_call' => [
        'classname' => 'block_alphabees\\external\\console_call',
        'methodname' => 'execute',
        'description' => 'Runs one Alphabees console operation as the signed-in Moodle user.',
        'type' => 'write',
        'ajax' => true,
        'loginrequired' => true,
    ],
];

$services = [
    'Alphabees AI Tutor' => [
        'shortname' => 'block_alphabees',
        'enabled' => 1,
        'restrictedusers' => 1,
        'downloadfiles' => 1,
        'uploadfiles' => 1,
        'functions' => [
            // Read paths — backend pulls course content into the knowledge base.
            'core_webservice_get_site_info',
            'core_course_get_courses',
            'core_course_get_courses_by_field',
            'core_course_get_contents',
            'core_course_get_categories',
            // Static content activities. Their intro/content is partly
            // visible through core_course_get_contents too, but the per-module
            // functions carry the fields that matter for the knowledge base
            // (url.externalurl, page.content, label.intro, book chapters).
            'mod_page_get_pages_by_courses',
            'mod_url_get_urls_by_courses',
            'mod_resource_get_resources_by_courses',
            'mod_folder_get_folders_by_courses',
            'mod_label_get_labels_by_courses',
            'mod_book_get_books_by_courses',
            'mod_imscp_get_imscps_by_courses',

            // Additional activity read paths — backend can ingest richer
            // course content when the corresponding Moodle activity plugins
            // expose these functions on the customer site.
            'mod_h5pactivity_get_h5pactivities_by_courses',
            'mod_lesson_get_lessons_by_courses',
            'mod_lesson_get_pages',
            'mod_lesson_get_page_data',
            'mod_lesson_get_pages_possible_jumps',
            'mod_quiz_get_quizzes_by_courses',
            'mod_assign_get_assignments',
            'mod_scorm_get_scorms_by_courses',
            'mod_wiki_get_wikis_by_courses',
            'mod_wiki_get_subwikis',
            'mod_wiki_get_subwiki_pages',
            'mod_wiki_get_page_contents',
            'mod_data_get_databases_by_courses',
            'mod_data_get_fields',
            'mod_data_get_entries',
            'mod_data_get_entry',
            'mod_data_search_entries',
            'mod_feedback_get_feedbacks_by_courses',
            'mod_feedback_get_items',
            'mod_glossary_get_glossaries_by_courses',
            'mod_glossary_get_categories',
            'mod_glossary_get_entries_by_letter',
            'mod_glossary_get_entry_by_id',
            'mod_choice_get_choices_by_courses',
            'mod_choice_get_choice_options',
            // The mod_survey plugin left core in Moodle 5.0 (optional since);
            // these resolve on 4.x sites only and are filtered out elsewhere
            // by partition_declared_service_functions().
            'mod_survey_get_surveys_by_courses',
            'mod_survey_get_questions',
            'mod_workshop_get_workshops_by_courses',
            'mod_lti_get_ltis_by_courses',
            'mod_bigbluebuttonbn_get_bigbluebuttonbns_by_courses',
            'mod_forum_get_forums_by_courses',
            'mod_forum_get_forum_discussions',
            'mod_forum_get_discussion_posts',
            'mod_forum_get_discussion_post',

            // Calendar read paths — course / site / group events so the
            // backend can surface deadlines and dates inside the tutor.
            // Personal (user-type) events of learners are not visible to
            // the service user and are intentionally out of scope.
            'core_calendar_get_calendar_events',
            'core_calendar_get_calendar_event_by_id',
            'core_calendar_get_calendar_monthly_view',
            'core_calendar_get_calendar_day_view',
            'core_calendar_get_calendar_upcoming_view',
            'core_calendar_get_action_events_by_course',
            'core_calendar_get_action_events_by_courses',
            'core_calendar_get_action_events_by_timesort',

            // Plugin-own data-minimised functions (defined in $functions above).
            'block_alphabees_get_forum_activity',
            'block_alphabees_get_user_calendar',
            'block_alphabees_get_course_completions',
            'block_alphabees_get_quiz_questions',
            'block_alphabees_discover_progress_sources',
            'block_alphabees_get_progress_trackers',
            'block_alphabees_get_rendered_course_texts',
            'block_alphabees_get_course_grades',
            'block_alphabees_get_course_fields',
            'block_alphabees_describe_functions',

            'core_enrol_get_users_courses',
            'core_enrol_get_enrolled_users',

            // User profiles — id, name, email, custom fields, last access.
            'core_user_get_users_by_field',
            'core_user_get_course_user_profiles',

            // Grades — per-user grade items, course-level overview, activity grades.
            'gradereport_user_get_grade_items',
            'gradereport_overview_get_course_grades',
            'mod_assign_get_grades',
            'mod_quiz_get_user_attempts',

            // Activity / course completion tracking.
            'core_completion_get_activities_completion_status',
            'core_completion_get_course_completion_status',
            // Completion write-back via token (alternative to the signed
            // inbound action set_activity_completion in api.php).
            'core_completion_override_activity_completion_status',

            // Groups — for filtering enrolment lists by class/cohort.
            'core_group_get_course_groups',
            'core_group_get_course_user_groups',

            // Write paths — backend pushes generated courses into Moodle.
            'core_course_create_courses',
            'core_course_update_courses',
            'core_course_delete_modules',
            'core_update_inplace_editable',
            'enrol_manual_enrol_users',
        ],
    ],
];
